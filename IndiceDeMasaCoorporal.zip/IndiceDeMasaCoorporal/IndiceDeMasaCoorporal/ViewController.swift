//
//  ViewController.swift
//  IndiceDeMasaCoorporal
//
//  Created by Tecnologico Roque on 8/28/19.
//  Copyright © 2019 Tecnologico Roque. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtPeso: UITextField!
    @IBOutlet weak var txtAltura: UITextField!
    @IBOutlet weak var lblResultado: UILabel!
    //declarcion de variables a nivel clase
    var peso: Double = 0.0
    var altura: Double = 0.0
    var imc: Double = 0.0
    //comprobar que las cajas de texto no esten vacias

    
    @IBAction func btnCalcular(_ sender: UIButton) {
        if (txtPeso.text?.isEmpty)!{
            lblResultado.text = "Falta de Capturar el peso"
            txtPeso.becomeFirstResponder() //mandar el cursor a la caja de texto que falto capturar
           
        }else
            if(txtAltura.text?.isEmpty)!{
                lblResultado.text = "Falta de capturar la altura"
                txtAltura.becomeFirstResponder()
                
            }else{
                peso = Double(txtPeso.text!)!
                altura = Double(txtAltura.text!)!
                imc  = peso/(altura*altura)
                lblResultado.text = "tu imc es de \(imc)"
        }
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

